/**
 * Single source of truth for the print catalogue.
 *
 * Metadata lives in src/content/prints/<slug>.json (Keystatic edits these).
 * The photograph itself lives at src/assets/prints/<slug>.jpg and is matched by
 * filename, so adding a print means dropping in one image and one JSON file.
 */
import type { ImageMetadata } from 'astro';

export type Print = {
  slug: string;
  title: string;
  where: string;
  orientation: 'landscape' | 'portrait';
  published: boolean;
  hero: boolean;
  image: ImageMetadata;
};

type Meta = Omit<Print, 'slug' | 'image'>;

const meta = import.meta.glob<Meta>('../content/prints/*.json', { eager: true, import: 'default' });
const art = import.meta.glob<ImageMetadata>('../assets/prints/*.jpg', { eager: true, import: 'default' });

const slugOf = (p: string) => p.split('/').pop()!.replace(/\.(json|jpg)$/, '');

const bySlug = new Map<string, ImageMetadata>(
  Object.entries(art).map(([path, img]) => [slugOf(path), img])
);

export const PRINTS: Print[] = Object.entries(meta)
  .map(([path, m]) => {
    const slug = slugOf(path);
    const image = bySlug.get(slug);
    if (!image) throw new Error(`No artwork at src/assets/prints/${slug}.jpg for ${slug}.json`);
    return { slug, image, ...m };
  })
  .filter((p) => p.published)
  .sort((a, b) => a.title.localeCompare(b.title));

/** Photographs that can carry the full-bleed homepage without an awkward crop. */
export const HEROES = PRINTS.filter((p) => p.hero);

export const findPrint = (slug: string) => PRINTS.find((p) => p.slug === slug);

export const SIZES = [
  { code: 'A4', mm: '210 × 297 mm', price: 5800 },
  { code: 'A3', mm: '297 × 420 mm', price: 9600 },
  { code: 'A2', mm: '420 × 594 mm', price: 16500 },
] as const;

export const CURRENCY = 'gbp';
export const money = (pence: number) => '£' + (pence / 100).toFixed(0);

export const PRINT_NOTE =
  'Made-to-order archival pigment print on Hahnemühle Photo Rag. Printed and shipped by ' +
  'theprintspace in London. Unframed, 5mm white border for handling.';
