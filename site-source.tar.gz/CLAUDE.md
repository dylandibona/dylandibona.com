# dylandibona.com — Development Notes

---

## Stack

| Layer | Technology |
|---|---|
| Framework | Astro 6.x, Vercel adapter |
| CMS | Keystatic (`storage: local`, dev only) |
| UI | React 19 (peer dep for Keystatic only — no React components ship) |
| Type | Area, from Adobe Fonts kit `yfz0paf` |
| Styles | One stylesheet, `src/styles/site.css` |

---

## The shape of the site

One photograph fills the viewport. Everything else is an index in the bottom left.
Opening a section never takes the photograph off screen: `ClientRouter` swaps the
document while `transition:persist` keeps `.stage`, `.track` and the loader alive.
Real URLs throughout, because a print needs an address someone can type off a wall.

`body[data-open]` drives every open/closed state in CSS. Home sets `false`, every
other route sets `true` via the layout's `open` prop. There is no JS toggling classes.

### Layout props
```astro
<Site title="…" description="…" open />
```

---

## Prints

**One image plus one JSON file makes a print.** Both are keyed by slug:

- `src/assets/prints/<slug>.jpg` — the photograph, 2500px, processed by Astro
- `src/content/prints/<slug>.json` — title, where, orientation, published, hero

`src/lib/prints.ts` joins them with `import.meta.glob` and **throws at build time**
if a JSON file has no matching image. A missing pair fails the build rather than
shipping a hole.

- `published: false` hides a print everywhere.
- `hero: true` lets a photograph fill the homepage. **Landscape only** — portraits
  crop badly full-bleed.
- `where: ""` renders nothing. Leave it blank rather than guessing.

Prices live in `SIZES` in `src/lib/prints.ts`, in pence. **They are invented** and
must be replaced with real CreativeHub cost plus margin before launch.

---

## Gotchas that cost real time

### The loader must be taken out of the layout, not just faded
It is `transition:persist`, but a route entered directly still ships its own copy of
the markup. Without the `window.__booted` guard adding `.gone` (`display:none`), that
fresh copy sits there as an opaque black sheet swallowing every click on the page.

### The hero controller is a singleton on `window.__hero`
Because the stage is persisted, re-running the initialiser on each navigation would
stack rotation timers. It builds once and exposes `sync()`, called on `astro:after-swap`.

### Adobe Fonts is loaded non-blocking, on purpose
A render-blocking stylesheet also blocks the inline scripts under it. If Adobe is slow,
a plain `<link rel=stylesheet>` leaves the loader unable to paint — a black screen for
as long as the request hangs. It is loaded with `rel=preload` + `onload`, with a
`<noscript>` fallback. Expect a brief FOUT. That is the correct trade.

### Adobe Fonts has no domain list
Web projects are not domain-restricted. `localhost`, Vercel previews and production all
work from the one kit. If Area is not rendering, it is not a domain problem.

### A hero that 404s must hand off, and the loader must self-clear
Both guards are load-bearing. Without them one missing file leaves the site a permanent
black screen. There is a hard 6-second clear regardless of what else happens.

### `astro preview` does not serve with the Vercel adapter
Use `npm run dev`, or deploy.

### `.npmrc` is required
`legacy-peer-deps=true` — Vercel's install fails without it on the Keystatic/Astro 6
peer dep conflict. Do not remove.

---

## Typography

`--sans` = `area-normal`, `--disp` = `area-extended`.

**Navigation is never set in capitals.** Sentence case, weight 300. Capitals are for
small tracked labels only: eyebrows, size rows, print locations, fine print, the loader.
The contact block is data rather than a label, so it is lowercase too.

Area ships real weights, but `font-synthesis:none` is set — never let a browser fake one.

---

## API routes

| Route | What |
|---|---|
| `/api/spotify` | Recently played, refresh-token flow, cached 60s at the edge |
| `/api/health` | Liveness check |

Spotify needs `SPOTIFY_CLIENT_ID`, `SPOTIFY_CLIENT_SECRET`, `SPOTIFY_REFRESH_TOKEN`
in Vercel. Locally it returns 500 without them; `/listening` degrades to a message
rather than an empty list.

---

## Not built yet

- **Checkout.** The Buy button selects a size and does nothing else. Planned:
  Stripe Elements plus the Express Checkout Element, Checkout Session from a Vercel
  function with slug and size in metadata, `checkout.session.completed` webhook creating
  the CreativeHub order, CreativeHub dispatch webhook emailing tracking.
  CreativeHub sandbox: `https://api.sandbox.tps-test.io`. Auth `Authorization: ApiKey <key>`.
  Webhooks are signed with HMAC in `X-Creativehub-Signature`.
- **The Letter.** Beehiiv does not exist yet. The form says so rather than pretending.
  Issue rows link nowhere.
- **Order status page.** Planned at a real URL so the dispatch email is one link.
